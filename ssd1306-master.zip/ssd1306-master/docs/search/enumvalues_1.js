var searchData=
[
  ['canvas_5fmode_5ftransparent',['CANVAS_MODE_TRANSPARENT',['../group___n_a_n_o___e_n_g_i_n_e___a_p_i.html#gga06fc87d81c62e9abb8790b6e5713c55ba98772cc8a02f04e00b7503800d2ab9ab',1,'canvas.h']]],
  ['canvas_5ftext_5fwrap',['CANVAS_TEXT_WRAP',['../group___n_a_n_o___e_n_g_i_n_e___a_p_i.html#gga06fc87d81c62e9abb8790b6e5713c55ba0f8baf412154ca8af0a985f1eac3853c',1,'canvas.h']]],
  ['canvas_5ftext_5fwrap_5flocal',['CANVAS_TEXT_WRAP_LOCAL',['../group___n_a_n_o___e_n_g_i_n_e___a_p_i.html#gga06fc87d81c62e9abb8790b6e5713c55ba2c6c98a4735704fd9e10e68e00a05363',1,'canvas.h']]]
];
